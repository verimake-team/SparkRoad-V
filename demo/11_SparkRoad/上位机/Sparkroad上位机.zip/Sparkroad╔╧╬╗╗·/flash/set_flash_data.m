function set_flash_data(data)
% 写入数据

ubus(5,data);

end