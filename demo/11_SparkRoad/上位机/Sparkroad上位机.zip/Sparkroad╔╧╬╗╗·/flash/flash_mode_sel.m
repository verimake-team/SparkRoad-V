function flash_mode_sel(mod_sel)
% 写入地址

% mod_sel == 0: 等待flash空闲
% mod_sel == 1: flash写使能
% mod_sel == 2: 擦除整个flash
% mod_sel == 3: 写入数据(1byte)到flash
% mod_sel == 4: 从flash读取数据(1byte)
% mod_sel == 5: 读取整个flash.
% mod_sel == 6: 读取芯片ID
% mod_sel == 7: 擦除flash一个扇区

ubus(3,mod_sel);

end