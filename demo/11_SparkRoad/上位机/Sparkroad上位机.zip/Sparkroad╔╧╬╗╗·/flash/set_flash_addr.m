function set_flash_addr(addr)
% 写入地址

ubus(4,addr);

end