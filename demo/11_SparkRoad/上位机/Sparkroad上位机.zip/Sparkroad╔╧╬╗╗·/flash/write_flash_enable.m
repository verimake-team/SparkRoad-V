function write_flash_enable()
% FLASH写使能

flash_mode_sel(1);

start();

end

